# XAIO / ACF package

This folder ships ready-to-use **ACF Local JSON** field groups plus a tiny **mu-plugin** that registers the required Custom Post Types & Taxonomies, loads the JSON, and applies the date-prefixed permalink rule.

## What’s inside

```
XAIO/ACF/
├─ acf-json/
│  └─ field-groups/
│     ├─ group_xaio_fact_fields.json
│     ├─ group_xaio_event_fields.json
│     ├─ group_xaio_report_fields.json
│     ├─ group_xaio_snippet_fields.json
│     ├─ group_xaio_evidence_fields.json
│     ├─ group_xaio_source_fields.json
│     ├─ group_xaio_organization_fields.json
│     └─ group_xaio_contributor_fields.json
└─ mu-plugins/
   └─ xaio-acf/
      ├─ xaio-cpts-tax.php
      ├─ xaio-acf-json-loader.php
      └─ acf-json/
         └─ field-groups/ (same JSON files, for drop-in use)
```

## Quick install (no UI clicking)

1. Copy the folder `XAIO/ACF/mu-plugins/xaio-acf` to your WordPress site at `wp-content/mu-plugins/xaio-acf/`.
   * mu-plugins autoload without activation.
2. Visit **Settings → Permalinks → Save** once to flush rewrite rules.
3. Go to **ACF → Field Groups**. You should see the 8 XAIO groups already active via Local JSON.

> Prefer using your theme’s `acf-json/`? Copy `XAIO/ACF/acf-json/field-groups/*` to `/wp-content/themes/your-theme/acf-json/` and remove `xaio-acf-json-loader.php`.

## Notes

* All ACF field types used are compatible with **ACF Free v6.1+**.
* Relationship-style links use **Relationship** (or Post Object) fields; these work in the free version.
* Custom Post Types & Taxonomies are registered with core `register_post_type()` and `register_taxonomy()` and exposed in REST.
* The date-prefixed slug rule applies to Fact/Event/Report/Snippet.

